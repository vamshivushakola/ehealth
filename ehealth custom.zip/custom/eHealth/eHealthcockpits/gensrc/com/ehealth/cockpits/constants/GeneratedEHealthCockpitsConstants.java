/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Aug 4, 2016 4:11:07 PM                      ---
 * ----------------------------------------------------------------
 */
package com.ehealth.cockpits.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedEHealthCockpitsConstants
{
	public static final String EXTENSIONNAME = "eHealthcockpits";
	
	protected GeneratedEHealthCockpitsConstants()
	{
		// private constructor
	}
	
	
}
